#!/system/bin/sh
# VCAM Auto-Scope - 自动将 VCAM 模块应用到所有已安装应用
# 在开机完成时运行，修改 LSPosed scope 数据库

MODDIR=${0%/*}
LSP_DB="/data/adb/lspd/config/modules_config.db"
MODULE_PKG="com.example.vcam"

# 等待 LSPosed 数据库就绪
for i in $(seq 1 30); do
    if [ -f "$LSP_DB" ]; then
        break
    fi
    sleep 2
done

if [ ! -f "$LSP_DB" ]; then
    echo "VCAM: LSPosed database not found" > /dev/kmsg
    exit 1
fi

# 获取所有已安装应用的包名
echo "VCAM: Updating LSPosed scope for all apps..." > /dev/kmsg

PKG_LIST=$(pm list packages 2>/dev/null | sed 's/package://g')

if [ -z "$PKG_LIST" ]; then
    # pm 不可用时从 packages.list 读取
    PKG_LIST=$(cat /data/system/packages.list 2>/dev/null | awk '{print $1}')
fi

COUNT=0
for pkg in $PKG_LIST; do
    # 跳过系统关键包（可能导致 bootloop）
    case "$pkg" in
        android|com.android.systemui|com.android.phone|com.android.settings)
            continue
            ;;
    esac
    
    # 跳过已有记录的包
    EXISTING=$(sqlite3 "$LSP_DB" "SELECT COUNT(*) FROM scope WHERE app_pkg_name='$pkg' AND module_pkg_name='$MODULE_PKG';" 2>/dev/null)
    if [ "$EXISTING" != "0" ]; then
        continue
    fi
    
    # 插入 scope 记录 (user_id=0)
    sqlite3 "$LSP_DB" "INSERT INTO scope (app_pkg_name, module_pkg_name, user_id) VALUES ('$pkg', '$MODULE_PKG', 0);" 2>/dev/null
    COUNT=$((COUNT + 1))
done

echo "VCAM: Added $COUNT apps to LSPosed scope" > /dev/kmsg

# 刷新 LSPosed（发送广播通知重新加载）
am broadcast -a org.lsposed.manager.action.RELOAD_MODULES 2>/dev/null

# 标记已执行
touch "$MODDIR/.scope_updated"
