LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := vcam_zygisk
LOCAL_SRC_FILES := main.cpp
LOCAL_CFLAGS := -std=c++17 -Wall -O2 -fvisibility=hidden
LOCAL_LDFLAGS := -llog
LOCAL_CPP_FEATURES := exceptions rtti
LOCAL_LDLIBS := -llog
LOCAL_SHARED_LIBRARIES :=
include $(BUILD_SHARED_LIBRARY)
