/*
 * VCAM Zygisk Module - 全局摄像头替换
 * 
 * 不依赖 LSPosed，通过 Zygisk 注入所有 app 进程，
 * 在 Native 层 Hook Camera1/Camera2 API，
 * 将摄像头画面替换为指定的视频文件。
 *
 * 编译: $NDK/ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=Android.mk
 * 或: cmake -DCMAKE_TOOLCHAIN_FILE=$NDK/build/cmake/android.toolchain.cmake ...
 */

#include <zygisk.hpp>
#include <jni.h>
#include <string>
#include <cstring>
#include <dlfcn.h>
#include <sys/stat.h>
#include <unistd.h>
#include <android/log.h>
#include <vector>
#include <mutex>
#include <thread>
#include <atomic>

#define LOG_TAG "VCAM-Zygisk"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ============ Configuration ============
static const char* VIDEO_PATH = "/data/local/tmp/vcam/virtual.mp4";
static const char* CONFIG_PATH = "/data/local/tmp/vcam_config.json";

// ============ Global State ============
static std::atomic<bool> g_hooksInstalled{false};
static std::mutex g_hookMutex;

// Camera resolution from config file
static int g_videoWidth = 0;
static int g_videoHeight = 0;

// ============ Config Reader ============
static bool readConfig() {
    FILE* f = fopen(CONFIG_PATH, "r");
    if (!f) {
        LOGI("config file not found: %s", CONFIG_PATH);
        return false;
    }
    
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    
    if (size <= 0 || size > 4096) {
        fclose(f);
        return false;
    }
    
    char* buf = new char[size + 1];
    fread(buf, 1, size, f);
    buf[size] = '\0';
    fclose(f);
    
    // Simple JSON parser - extract video_width and video_height
    auto findInt = [&](const char* key) -> int {
        std::string s(buf);
        size_t pos = s.find(std::string("\"") + key + "\"");
        if (pos == std::string::npos) return 0;
        pos = s.find(":", pos);
        if (pos == std::string::npos) return 0;
        // Skip whitespace and colon
        while (++pos < s.length() && (s[pos] == ' ' || s[pos] == ':' || s[pos] == '\t'));
        if (pos >= s.length()) return 0;
        return atoi(s.c_str() + pos);
    };
    
    g_videoWidth = findInt("video_width");
    g_videoHeight = findInt("video_height");
    
    delete[] buf;
    
    LOGI("config: video %dx%d", g_videoWidth, g_videoHeight);
    return (g_videoWidth > 0 && g_videoHeight > 0);
}

// ============ ART Method Hooking ============
// 使用 JNI 获取 Java 方法 ID 并替换其 native 实现

static JavaVM* g_jvm = nullptr;

// 检查视频文件是否存在且可读
static bool isVideoAvailable() {
    struct stat st;
    return (stat(VIDEO_PATH, &st) == 0 && st.st_size > 0 && (st.st_mode & S_IRGRP));
}

// ============ Camera1 Hook - android.hardware.Camera ============

// 保存原始方法引用
static jmethodID g_orig_startPreview = nullptr;
static jmethodID g_orig_setPreviewCallback = nullptr;
static jmethodID g_orig_setPreviewDisplay = nullptr;

// Hook 的 startPreview 实现（将原 Surface 替换为虚拟 Surface）
static void hook_startPreview(JNIEnv* env, jobject thiz) {
    if (!isVideoAvailable()) {
        // 视频不可用，走原始逻辑
        if (g_orig_startPreview) {
            env->CallVoidMethod(thiz, g_orig_startPreview);
        }
        return;
    }
    
    LOGI("Camera1: startPreview hooked");
    
    // 读取配置
    readConfig();
    
    // TODO: 创建虚拟 SurfaceTexture 并将视频解码到其中
    // 1. 创建 SurfaceTexture + Surface
    // 2. 使用 MediaCodec 解码视频到 Surface
    // 3. 调用 Camera.setPreviewTexture(fakeTexture)
    // 4. 调用原始 startPreview
    
    // 当前：先调用原始逻辑，让后续 setPreviewCallback hook 来替换帧数据
    if (g_orig_startPreview) {
        env->CallVoidMethod(thiz, g_orig_startPreview);
    }
}

// Hook setPreviewCallbackWithBuffer - 替换预览帧数据
static void hook_setPreviewCallbackWithBuffer(JNIEnv* env, jobject thiz, jobject cb) {
    LOGI("Camera1: setPreviewCallbackWithBuffer hooked");
    
    if (!isVideoAvailable()) {
        // Pass through
        static jmethodID orig = nullptr;
        if (!orig) {
            jclass camClass = env->GetObjectClass(thiz);
            orig = env->GetMethodID(camClass, "setPreviewCallbackWithBuffer",
                "(Landroid/hardware/Camera$PreviewCallback;)V");
        }
        if (orig) env->CallVoidMethod(thiz, orig, cb);
        return;
    }
    
    // TODO: 拦截预览回调，在 onPreviewFrame 中将摄像头数据替换为视频帧
    // 这需要创建代理 Callback 对象
    
    static jmethodID orig = nullptr;
    if (!orig) {
        jclass camClass = env->GetObjectClass(thiz);
        orig = env->GetMethodID(camClass, "setPreviewCallbackWithBuffer",
            "(Landroid/hardware/Camera$PreviewCallback;)V");
    }
    if (orig) env->CallVoidMethod(thiz, orig, cb);
}

// ============ Camera2 Hook - android.hardware.camera2.CameraManager ============
static jmethodID g_orig_openCamera = nullptr;

// Hook CameraManager.openCamera
static void hook_openCamera(JNIEnv* env, jobject thiz, jstring cameraId,
                             jobject callback, jobject handler) {
    const char* idStr = env->GetStringUTFChars(cameraId, nullptr);
    LOGI("Camera2: openCamera hooked, id=%s", idStr);
    env->ReleaseStringUTFChars(cameraId, idStr);
    
    if (!isVideoAvailable()) {
        if (g_orig_openCamera) {
            env->CallVoidMethod(thiz, g_orig_openCamera, cameraId, callback, handler);
        }
        return;
    }
    
    readConfig();
    
    // TODO: 创建虚拟 CameraDevice，拦截 onOpened/onConfigured 回调
    // 替换 CaptureRequest 的 Surface target 为虚拟 Surface
    // 将视频解码到虚拟 Surface
    
    // 当前：调用原始逻辑，后续 addTarget 等 hook 再拦截
    if (g_orig_openCamera) {
        env->CallVoidMethod(thiz, g_orig_openCamera, cameraId, callback, handler);
    }
}

// ============ JNI Registration ============

// Android 7.0+ ART JNI hooking via RegisterNatives 替换
static bool registerNativeHooks(JNIEnv* env) {
    jclass cameraClass = env->FindClass("android/hardware/Camera");
    if (!cameraClass) {
        LOGE("Failed to find android.hardware.Camera");
        return false;
    }
    
    // Save original method IDs
    g_orig_startPreview = env->GetMethodID(cameraClass, "startPreview", "()V");
    g_orig_setPreviewCallback = env->GetMethodID(cameraClass, "setPreviewCallbackWithBuffer",
        "(Landroid/hardware/Camera$PreviewCallback;)V");
    g_orig_setPreviewDisplay = env->GetMethodID(cameraClass, "setPreviewDisplay",
        "(Landroid/view/SurfaceHolder;)V");
    
    // Use RegisterNatives to replace native implementations
    // Note: Camera.startPreview is a Java method, not native.
    // For Java method hooking, we need Xposed-like ART hooking or
    // use JNI trampoline to redirect the method entry.
    //
    // The simplest approach: modify the ArtMethod entry point directly
    // using the Zygisk API's plt hook or inline hook.
    
    LOGI("Camera1 methods found: startPreview=%p setPreviewCB=%p",
         g_orig_startPreview, g_orig_setPreviewCallback);
    
    jclass camManagerClass = env->FindClass("android/hardware/camera2/CameraManager");
    if (camManagerClass) {
        g_orig_openCamera = env->GetMethodID(camManagerClass, "openCamera",
            "(Ljava/lang/String;Landroid/hardware/camera2/CameraDevice$StateCallback;Landroid/os/Handler;)V");
        LOGI("Camera2 openCamera found: %p", g_orig_openCamera);
    }
    
    return true;
}

// ============ ART Method Entry Point Hook ============
// Directly patch ArtMethod::entry_point_from_quick_compiled_code_
// This is device/version-specific and requires careful handling.

static void* getArtMethodEntry(JNIEnv* env, jclass clazz, const char* name, const char* sig) {
    jmethodID method = env->GetMethodID(clazz, name, sig);
    if (!method) {
        method = env->GetStaticMethodID(clazz, name, sig);
    }
    if (!method) return nullptr;
    
    // ArtMethod structure (Android 9+):
    // The method ID is a pointer to the ArtMethod structure.
    // entry_point_from_quick_compiled_code_ is at offset that varies by version.
    // For simplicity, we use a fixed offset that works on Android 12+.
    
    // On Android 12 (API 31): ArtMethod entry point is typically at +0x18 or +0x20
    // We need to read the actual offset from the runtime or use a heuristic.
    
    return method; // Return the ArtMethod pointer for further processing
}

// ============ Zygisk Module Entry Points ============

class VCamZygiskModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api* api, JNIEnv* env) override {
        this->api = api;
        this->env = env;
        env->GetJavaVM(&g_jvm);
        
        LOGI("VCAM Zygisk module loaded");
        api->setOption(zygisk::Option::DLCLOSE_DISABLED);
    }
    
    void preAppSpecialize(zygisk::AppSpecializeArgs* args) override {
        // Enable hooks for ALL apps (global replacement)
        // The actual video replacement only activates when video file exists
        // and VCamConfig.isHookDisabled() is false (read from config file)
    }
    
    void postAppSpecialize(const zygisk::AppSpecializeArgs* args) override {
        const char* process = env->GetStringUTFChars(
            (jstring)api->getOption(zygisk::PROCESS_NAME), nullptr);
        
        // Skip system_server (hook it separately for camera service hooks)
        if (!process || strcmp(process, "android") == 0) {
            if (process) env->ReleaseStringUTFChars((jstring)api->getOption(zygisk::PROCESS_NAME), process);
            return;
        }
        
        LOGI("Injecting into process: %s", process);
        
        // Register native hooks in this process
        std::lock_guard<std::mutex> lock(g_hookMutex);
        if (!g_hooksInstalled.load()) {
            registerNativeHooks(env);
            g_hooksInstalled.store(true);
        }
        
        if (process) env->ReleaseStringUTFChars((jstring)api->getOption(zygisk::PROCESS_NAME), process);
    }
    
    void preServerSpecialize(zygisk::ServerSpecializeArgs* args) override {
        // system_server - could hook camera service here
        LOGI("system_server: camera service hook opportunity");
    }

private:
    zygisk::Api* api = nullptr;
    JNIEnv* env = nullptr;
};

// Register the module
REGISTER_ZYGISK_MODULE(VCamZygiskModule)
