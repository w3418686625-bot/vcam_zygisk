#!/system/bin/sh
# VCAM Zygisk Module - post-fs-data
# Runs early in boot, before most services start

MODDIR=${0%/*}

# Create video storage directory with proper permissions
VIDEO_DIR="/data/local/tmp/vcam"
mkdir -p "$VIDEO_DIR"
chmod 777 "$VIDEO_DIR"
chown system:system "$VIDEO_DIR"

# Ensure config file is world-readable
CONFIG_FILE="/data/local/tmp/vcam_config.json"
if [ -f "$CONFIG_FILE" ]; then
    chmod 644 "$CONFIG_FILE"
fi

# Log module activation
echo "VCAM: post-fs-data complete, video_dir=$VIDEO_DIR" > /dev/kmsg
